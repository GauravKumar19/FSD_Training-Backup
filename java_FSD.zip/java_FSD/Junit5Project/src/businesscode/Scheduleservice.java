package businesscode;

public class Scheduleservice {

	public boolean doSchedule() {
		//TODO: put logic here
		return true;
		}

		public boolean backupCalendar() {
		// TODO: put logic here
		return true;
		}
}
