package com.coforge.training.mockitodemo;

public class NetworkDao {

	public void save(String fileName) {
		System.out.println("Saved in network Location");
	}
}
