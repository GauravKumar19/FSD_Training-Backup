package com.coforge.training.mockitodemo;

public interface Idemo {
	
	String S = "Hello World" ; // By default Constant
	
	String greet(); // By default Abstract

}
