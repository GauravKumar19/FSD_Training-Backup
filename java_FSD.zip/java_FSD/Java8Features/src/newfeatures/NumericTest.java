package newfeatures;

@FunctionalInterface
public interface NumericTest {

	boolean computetest(int n);
}
