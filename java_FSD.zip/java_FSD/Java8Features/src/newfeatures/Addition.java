package newfeatures;

@FunctionalInterface
public interface Addition {

	public int calculate(int a, int b);
}
