package newfeatures;

@FunctionalInterface
public interface Mystring {

	String mystringfunction(String str);
}
